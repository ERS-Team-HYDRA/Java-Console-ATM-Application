package com.BankingApplication;

import java.sql.*;

public class UserDAO extends User
{
    private int accNo;
    private String accName;
    private Long accPin;
    private Long accBalance;
    private Long accMobile;
    private String accountNumbers;
    private int accounts;
    
    public UserDAO(){}
    
    public UserDAO(int accounts, int accNo, String accName, Long accPin, Long accBalance, Long accMobile, String accountNumbers, int userAccNumber, String userName, long pin, long wAmount, long dAmount, long newPin)
    {
        super(userAccNumber, userName, pin, wAmount, dAmount, newPin);
        this.accNo= accNo;
        this.accName= accName;
        this.accPin= accPin;
        this.accBalance= accBalance;
        this.accMobile= accMobile;
        this.accountNumbers= accountNumbers;
        this.accounts= accounts;
    }
    
    /**
     * @return int return the accNo
     */
    public int getAccounts()
    {
        return accounts;
    }

    /**
     * @param accNo the accNo to set
     */
    public void setAccounts(int accounts)
    {
        this.accounts = accounts;
    }
    
    /**
     * @return int return the accNo
     */
    public String getAccountNumbers()
    {
        return accountNumbers;
    }

    /**
     * @param accNo the accNo to set
     */
    public void setAccountNumbers(String accountNumbers)
    {
        this.accountNumbers = accountNumbers;
    }

    /**
     * @return int return the accNo
     */
    public int getAccNo()
    {
        return accNo;
    }

    /**
     * @param accNo the accNo to set
     */
    public void setAccNo(int accNo)
    {
        this.accNo = accNo;
    }

    /**
     * @return String return the accName
     */
    public String getAccName()
    {
        return accName;
    }

    /**
     * @param accName the accName to set
     */
    public void setAccName(String accName)
    {
        this.accName = accName;
    }

    /**
     * @return Long return the accPin
     */
    public Long getAccPin()
    {
        return accPin;
    }

    /**
     * @param accPin the accPin to set
     */
    public void setAccPin(Long accPin)
    {
        this.accPin = accPin;
    }

    /**
     * @return Long return the accBalance
     */
    public Long getAccBalance()
    {
        return accBalance;
    }

    /**
     * @param accBalance the accBalance to set
     */
    public void setAccBalance(Long accBalance)
    {
        this.accBalance = accBalance;
    }

    /**
     * @return Long return the accMobile
     */
    public Long getAccMobile()
    {
        return accMobile;
    }

    /**
     * @param accMobile the accMobile to set
     */
    public void setAccMobile(Long accMobile)
    {
        this.accMobile = accMobile;
    }
    
    /* ASSIGNING VALUES TO FIELDS */
    public void displayUsers() throws Exception
    {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection conn= DBConnection.getConnection();
        String query = "Select * from BankApplication where AccNo="+this.getUserAccNumber();
        Statement s = conn.createStatement();
        ResultSet rs = s.executeQuery(query);
        
        while(rs.next())
        {
            this.accNo= rs.getInt(1);
            this.accName= rs.getString(2);
            this.accPin= rs.getLong(3);
            this.accMobile= rs.getLong(4);
            this.accBalance= rs.getLong(5);
        }
        
        conn.close();
        s.close();
    }

    /* VERIFYING ACCOUNT NUMBER */
    public void accountCheck() throws Exception
    {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection conn= DBConnection.getConnection();
        String accQuerry= "Select count(AccNo) from BankApplication";
        PreparedStatement ps= conn.prepareStatement(accQuerry);
        ResultSet rs= ps.executeQuery(accQuerry);
        
        while(rs.next())
        {
            int x= rs.getInt(1);
            this.setAccounts(x);
        }
        
        conn.close();
        ps.close();
    }

    /* UPDATING BALANCE AFTER BANKING */
    public void updateBalance() throws Exception
    {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection conn= DBConnection.getConnection();
        String balanceQuerry="Update BankApplication set Balance="+this.getAccBalance()+"where AccNo="+this.getUserAccNumber();
        PreparedStatement ps=conn.prepareStatement(balanceQuerry);
        ResultSet rs= ps.executeQuery(balanceQuerry);
        String finalBalance="Select Balance from BankApplication where AccNo="+this.getUserAccNumber();
        ps= conn.prepareStatement(finalBalance);
        rs = ps.executeQuery(finalBalance);
        
        while(rs.next())
        {
            this.accBalance= rs.getLong(1);
        }
        
        conn.close();
        ps.close();
    }

    /* UPDATING PIN */
    public void updatePin() throws Exception
    {
        int len= String.valueOf(this.getNewPin()).length();
        if(len==4)
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn= DBConnection.getConnection();
            String pinQuerry="Update BankApplication set Pin="+this.getNewPin()+"where AccNo="+this.getUserAccNumber();
            PreparedStatement ps=conn.prepareStatement(pinQuerry);
            ResultSet rs= ps.executeQuery(pinQuerry);
            String finalPin="Select Pin from BankApplication where AccNo="+this.getUserAccNumber();
            ps= conn.prepareStatement(finalPin);
            rs = ps.executeQuery(finalPin);
            
            while(rs.next())
            {
                this.setPin(rs.getLong(1));
            }
            
            conn.close();
            ps.close();
        }
        
        else
        {
            System.out.println("--> PIN must be 4-digit!!\n--> Thank you for banking with us.");
        }
    }
}

/**************************************************************************
 * (C) Copyright 2022-2035 by Team HYDRA,                                 *
 * Inc. All Rights Reserved.                                              *
 *                                                                        *
 * DISCLAIMER: The authors and publishers of this code have used their    *
 * best efforts in preparing the code. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publishers make      *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these codes. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/