package com.BankingApplication;

public class User
{
    private int userAccNumber;
    private String userName;
    private long pin;
    private long wAmount;
    private long dAmount;
    private long newPin;
    
    public User(){}
    
    public User(int userAccNumber, String userName, long pin, long wAmount, long dAmount, long newPin)
    {
        this.dAmount= dAmount;
        this.newPin= newPin;
        this.pin= pin;
        this.userName= userName;
        this.wAmount= wAmount;
    }
    
    /**
     * @return int return the userAccNumber
     */
    public int getUserAccNumber()
    {
        return userAccNumber;
    }

    /**
     * @param userAccNumber the userAccNumber to set
     */
    public void setUserAccNumber(int userAccNumber)
    {
        this.userAccNumber = userAccNumber;
    }

    /**
     * @return String return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    /**
     * @return long return the pin
     */
    public long getPin()
    {
        return pin;
    }

    /**
     * @param pin the pin to set
     */
    public void setPin(long pin)
    {
        this.pin = pin;
    }
    
    /**
     * @return long return the wAmount
     */
    public long getWAmount()
    {
        return wAmount;
    }

    /**
     * @param wAmount the wAmount to set
     */
    public void setWAmount(long wAmount)
    {
        this.wAmount = wAmount;
    }

    /**
     * @return long return the dAmount
     */
    public long getDAmount() {
        return dAmount;
    }

    /**
     * @param dAmount the dAmount to set
     */
    public void setDAmount(long dAmount)
    {
        this.dAmount = dAmount;
    }

    /**
     * @return long return the newPin
     */
    public long getNewPin()
    {
        return newPin;
    }

    /**
     * @param newPin the newPin to set
     */
    public void setNewPin(long newPin)
    {
        this.newPin = newPin;
    }
}

/*************************************************************************
* (C) Copyright 2022-2035 by Team HYDRA,                                 *
* Inc. All Rights Reserved.                                              *
*                                                                        *
* DISCLAIMER: The authors and publishers of this code have used their    *
* best efforts in preparing the code. These efforts include the          *
* development, research, and testing of the theories and programs        *
* to determine their effectiveness. The authors and publishers make      *
* no warranty of any kind, expressed or implied, with regard to these    *
* programs or to the documentation contained in these codes. The authors *
* and publisher shall not be liable in any event for incidental or       *
* consequential damages in connection with, or arising out of, the       *
* furnishing, performance, or use of these programs.                     *
*************************************************************************/