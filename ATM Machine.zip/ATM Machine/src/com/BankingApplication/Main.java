package com.BankingApplication;

import java.util.*;

public class Main
{
    public static void main(String args[]) throws Exception
    {
        Methods m= new Methods();
        Scanner sc= new Scanner(System.in);

        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("*********************************************");
        System.out.println("*********** WELCOME TO HYDRA BANK ***********");
        System.out.println();

        /* CATCHING INVALID DATA TYPE INPUT */
        try
        {
            /* GETTING USER DETAILS */
            System.out.print("--> Enter your account number: ");
            m.setUserAccNumber(sc.nextInt());
            System.out.println();

            /* VERIFYING ACCOUNT NUMBER */
            if(m.verifyAccNo())
            {
                System.out.print("--> Enter you PIN: ");
                m.setPin(sc.nextLong());
                m.displayUsers();

                System.out.println();
                /* PIN VERIFICATION */
                if(m.verifyPin())
                {
                    System.out.println("--> Welcome "+m.getAccName()+"!!!");
                    System.out.println();
                    boolean cancel=true;    
                    
                    do
                    {
                        /* GETTING TRANSACTION CHOICE */
                        System.out.println("--> Press 1 for MINI STATEMENT\n"+"--> Press 2 for BANKING\n"+"--> Press 3 for PIN CHANGE\n"+"--> Press 4 to EXIT");
                        System.out.print("--> CHOICE: ");
                        int userInput1= sc.nextInt();
                        System.out.println();

                        switch(userInput1)
                        {
                            /* MINI STATEMENT */
                            case 1: System.out.println("--> Your account balance is "+m.getAccBalance());
                            boolean invalidOption= false;
                            
                            do
                            {
                                System.out.println("--> Press 1 to GO TO PREVIOUS MENU\n--> Press 2 to EXIT");
                                System.out.print("--> CHOICE: ");
                                int opt= sc.nextInt();
                                System.out.println();
                                
                                switch(opt)
                                {
                                    case 1: invalidOption= false;
                                    break;
                                    
                                    case 2: invalidOption= false;
                                    cancel= false;
                                    break;
                                    
                                    default: System.out.println("--> INCORRECT CHOICE!!");
                                    invalidOption= true;
                                    break;
                                }
                            }
                            
                            while(invalidOption);
                            break;
                            
                            /* BANKING */
                            case 2: System.out.println("--> Press 1 for WITHDRAWAL\n"+"--> Press 2 for DEPOSIT\n"+"--> Press 3 to GO TO PREVIOUS MENU");
                            System.out.print("--> CHOICE: ");
                            int userInput2= sc.nextInt();
                            System.out.println();
                            
                            switch(userInput2)
                            {
                                /* WITHDRAWAL */
                                case 1: System.out.print("--> Your account balance is "+m.getAccBalance()+"\n--> Please maintain minimum balance of 500\n"+"--> Enter WITHDRAWAL AMOUNT: ");
                                m.setWAmount(sc.nextLong());
                                m.withdrawal();
                                System.out.println();
                                boolean opt= false;
                                
                                do
                                {
                                    System.out.println("--> Press 1 to GO TO MAIN MENU\n--> Press 2 to EXIT");
                                    System.out.print("--> CHOICE: ");
                                    int choice= sc.nextInt();
                                    System.out.println();
                                    
                                    switch(choice)
                                    {
                                        case 1: opt= false;
                                        break;
                                        
                                        case 2: opt= false;
                                        cancel= false;
                                        break;
                                                        
                                        default: System.out.println("--> INCORRECT CHOICE!!");
                                        opt= true;
                                        break;
                                    }
                                }
                               
                                while(opt);
                                break;
                                
                                /* DEPOSIT */
                                case 2: System.out.print("--> Your account balance is "+m.getAccBalance()+"\n--> Please enter amount upto 500000\n"+"--> Enter DEPOSIT AMOUNT: ");
                                m.setDAmount(sc.nextLong());
                                m.deposit();
                                System.out.println();
                                boolean option= false;
                                
                                do
                                {
                                    System.out.println("--> Press 1 to GO TO MAIN MENU\n--> Press 2 to EXIT");
                                    System.out.print("--> CHOICE: ");
                                    int choice= sc.nextInt();
                                    System.out.println();
                                    
                                    switch(choice)
                                    {
                                        case 1: option= false;
                                        break;
                                                        
                                        case 2: option= false;
                                        cancel= false;
                                        break;
                                                       
                                        default: System.out.println("--> INCORRECT CHOICE!!");
                                        option= true;
                                        break;
                                    }
                                }
                                
                                while(option);
                                break;
                                
                                /* PREVIOUS MENU */
                                case 3: break;

                                /* INVALID CHOICE */
                                default: System.out.println("--> INVALID CHOICE!!\n--> Thank you for banking with us.");
                                break;
                            }
                            
                            break;

                            /* PIN CHANGE */
                            case 3: System.out.print("--> Please re-confirm your current PIN: ");
                            Long pin= sc.nextLong();
                            m.setPin(pin);

                            if(m.verifyPin())
                            {
                                System.out.print("--> Enter your new 4-digit PIN: ");
                                m.setNewPin(sc.nextLong());
                                m.changePin();
                            }
                            
                            else
                            {
                                System.out.println("--> INCORRECT PIN!!\n");
                            }
                            
                            cancel= false;
                            break;
                            
                            /* EXIT */
                            case 4: cancel=false;
                            break;

                            /* INVALID CHOICE */
                            default: System.out.println("--> INCORRECT CHOICE!!");
                            break;
                        }
                    }
                    
                    while(cancel);
                    System.out.println("******* THANK YOU FOR BANKING WITH US *******");
                }

                /* INCORRECT PIN */
                else
                {
                    System.out.println("--> Incorrect PIN!!\n");
                    
                    System.out.println();
                    System.out.println("******* THANK YOU FOR BANKING WITH US *******");
                }
            }
                
            /* INCORRECT ACCOUNT NUMBER */
            else
            {
                System.out.println("--> INCORRECT ACCOUNT NUMBER!!");
                System.out.println();
                System.out.println("******* THANK YOU FOR BANKING WITH US *******");
            }
        }
        
        /* CATCHING INVALID DATA TYPE INPUT */
        catch (InputMismatchException e)
        {
            System.out.println();
            System.out.println("--> INVALID INPUT!!");
            System.out.println();
            System.out.println("******* THANK YOU FOR BANKING WITH US *******");
        }
        
        System.out.println("*********************************************");
        System.out.println();
        long millis = System.currentTimeMillis();  
        java.util.Date date = new java.util.Date(millis);
        System.out.println(date);
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        sc.close();
    }
}

/**************************************************************************
 * (C) Copyright 2022-2035 by Team HYDRA,                                 *
 * Inc. All Rights Reserved.                                              *
 *                                                                        *
 * DISCLAIMER: The authors and publishers of this code have used their    *
 * best efforts in preparing the code. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publishers make      *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these codes. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/