package com.BankingApplication;

public class Methods extends UserDAO
{
    public Methods()
    {
        super();
    }
    
    public Methods(int accNo, String accName, Long accPin, Long accBalance, Long accMobile, int userAccNumber, String userName, long pin, long balance, long wAmount, long dAmount, long newPin)
    {
        super();
    }
    
    /* VERIFYING ACCOUNT NUMBER */
    public boolean verifyAccNo() throws Exception
    {
        accountCheck();
        
        if(this.getUserAccNumber() <= this.getAccounts() && this.getUserAccNumber() >= 1)
        {
            return true;
        }
        
        else
        {
            return false;
        }
    }
    
    /* VERIFYING PIN */
    public boolean verifyPin()
    {
        int len= String.valueOf(this.getPin()).length();
        
        if(this.getAccPin().equals(this.getPin()) && len==4)
        {
            return true;
        }
        
        else
        {
            return false;
        }
    }
    
    /* WITHDRAWAL */
    public void withdrawal() throws Exception
    {
        if(this.getWAmount()<=0)
        {
            System.out.println("--> Please enter a valid amount for WITHDRAWAL!!");
        }

        if(this.getWAmount()<= this.getAccBalance()-500 && this.getWAmount()>0)
        {
            Long newBalance= this.getAccBalance()-this.getWAmount();
            this.setAccBalance(newBalance);
            updateBalance();
            System.out.println("--> WITHDRAWAL of "+this.getWAmount()+" SUCESSFUL!!");
            System.out.println("--> Your NEW BALANCE IS: "+this.getAccBalance());
        }
        
        if(this.getWAmount()>this.getAccBalance()-500)
        {
            System.out.println("--> MINIMUM BALANCE of 500 must be maintained!!");
        }
    }

   /* DEPOSIT */
   public void deposit() throws Exception
   {
       if(this.getDAmount()<=0)
        {
           System.out.println("--> Please enter a valid amount for DEPOSIT!!");
        }
        if(this.getDAmount()<= 500000 && this.getDAmount()>0)
        {
            Long newBalance= this.getAccBalance()+this.getDAmount();
            this.setAccBalance(newBalance);
            updateBalance();
            System.out.println("--> DEPOSIT of "+this.getDAmount()+" SUCESSFUL!!");
            System.out.println("--> Your NEW BALANCE IS: "+this.getAccBalance());
        }
        
        if(this.getDAmount()>500000)
        {
            System.out.println("--> Amount exceeds limit!!\n--> Kindly visit branch!!");
        }
    }

    /* UPDATING PIN */
    public void changePin() throws Exception
    {
        updatePin();
        System.out.println();
    }
}

/**************************************************************************
 * (C) Copyright 2022-2035 by Team HYDRA,                                 *
 * Inc. All Rights Reserved.                                              *
 *                                                                        *
 * DISCLAIMER: The authors and publishers of this code have used their    *
 * best efforts in preparing the code. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publishers make      *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these codes. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/