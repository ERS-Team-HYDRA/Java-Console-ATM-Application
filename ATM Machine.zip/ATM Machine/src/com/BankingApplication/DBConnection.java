package com.BankingApplication;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection
{
    public static Connection getConnection() throws ClassNotFoundException, SQLException
    {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String username = "SYSTEM";
        String password = "SYSTEM";
        Connection conn = DriverManager.getConnection(url,username,password);
        return conn;
    }
}

/**************************************************************************
 * (C) Copyright 2022-2035 by Team HYDRA,                                 *
 * Inc. All Rights Reserved.                                              *
 *                                                                        *
 * DISCLAIMER: The authors and publishers of this code have used their    *
 * best efforts in preparing the code. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publishers make      *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these codes. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/